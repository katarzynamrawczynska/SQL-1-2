
USE BS
GO



/* z��czenie poziome - JOIN*/

SELECT * FROM tblPracownicy; -- id 2 - nie przypisany do sprzeda�y
SELECT * FROM tblSprzedaz; -- id 6, 11, 20, 39, 141 - brak przypisanego pracownika

-- INNER JOIN: co najmniej jeden dopasowany rekord w obu tabelach
SELECT  *-- p.*, s.*, s.ID_Sprzedaz, p.IDPracownika
FROM dbo.tblPracownicy AS p
INNER JOIN dbo.tblSprzedaz AS s ON p.IDPracownika = s.Pracownik_ID;
-- TODO Dodajmy WHERE

-- LEFT JOIN: wiersze z lewej tabeli i dopasowane z prawej
SELECT *
FROM dbo.tblPracownicy AS p
LEFT JOIN dbo.tblSprzedaz AS s ON p.IDPracownika = s.Pracownik_ID;
-- TODO dodajmy warunek key IS NULL

-- RIGHT JOIN: wiersze z prawej tabeli i dopasowane z lewej
SELECT *
FROM dbo.tblPracownicy AS p
RIGHT JOIN dbo.tblSprzedaz AS s ON p.IDPracownika = s.Pracownik_ID;

-- TODO - co gdy zmienimy kolejno�� tabel?


-- FULL JOIN (FULL OUTER JOIN): wiersze z lewej i prawej tabeli
SELECT p.*, s.DataSprzedazy
FROM dbo.tblPracownicy AS p
FULL JOIN dbo.tblSprzedaz AS s ON p.IDPracownika = s.Pracownik_ID;



SELECT * 
/*
	 sp.ID_Sprzedaz, 
	sp.DataSprzedazy,   
	o_sp.Ilosc,
	o_sp.Towar_ID,
	k.NazwaFirmy,
	p.Nazwisko
*/
FROM tblSprzedaz sp -- wiele JOIN -- Czy s� jakie� zasady co do kolejno�ci ?
JOIN tblOpisSprzedazy o_sp ON sp.ID_Sprzedaz = o_sp.Sprzedaz_ID
JOIN tblKlienci k ON k.ID_Klient = sp.Klient_ID
JOIN tblPracownicy p ON p.IDPracownika = sp.Pracownik_ID
-- TODO dodajmy pozosta�e tabele


/* �wiczenia */
-- 1. Wyci�gnij imiona i nazwiska WSZYSTKICH pracownik�w, oraz id i dat� sprzedarzy, je�li brali w niej udzia�
-- 2. Wy�wietl opisy sprzeda�y (ca�e dane) wraz z nazwami sprzedanych produkt�w
-- 3. do punktu 2. dodaj nazwy kategorii produkt�w, wyniki ogranicz do towar�w z kategorii 2,3,4.
-- wyci�gnij dane wszystkich pracownik�w, kt�rzy nie brali udzia�u w �adnej sprzedarzy
--		(w warunku b�dzie potrzebne id sprzeda�y o warto�ci NULL)




/* �wiczenia */
-- 1. Wyci�gnij imiona i nazwiska WSZYSTKICH pracownik�w, oraz id i dat� sprzedarzy, je�li brali w niej udzia�
-- 2. Wy�wietl opisy sprzeda�y (ca�e dane) wraz z nazwami sprzedanych produkt�w
-- 3. do punktu 2. dodaj nazwy kategorii produkt�w, wyniki ogranicz do towar�w z kategorii 2,3,4.
-- wyci�gnij dane wszystkich pracownik�w, kt�rzy nie brali udzia�u w �adnej sprzedarzy
--		(w warunku b�dzie potrzebne id sprzeda�y o warto�ci NULL)
-- 1. Imiona i nazwiska WSZYSTKICH pracownik�w oraz id i dat� sprzeda�y, je�li brali w niej udzia�
SELECT p.Imie, p.Nazwisko, s.ID_Sprzedaz, s.DataSprzedazy
FROM tblPracownicy p
LEFT JOIN tblSprzedaz s ON p.IDPracownika = s.Pracownik_ID;

-- 2. Opisy sprzeda�y (ca�e dane) wraz z nazwami sprzedanych produkt�w
SELECT os.*, t.NazwaTowaru
FROM tblOpisSprzedazy os
JOIN tblTowary t ON os.Towar_ID = t.ID_Towar;

-- 3. Opisy sprzeda�y z nazwami produkt�w i ich kategorii, ograniczone do kategorii 2, 3, 4
SELECT os.*, t.NazwaTowaru, k.NazwaKategorii
FROM tblOpisSprzedazy os
JOIN tblTowary t ON os.Towar_ID = t.ID_Towar
JOIN tblKategorie k ON t.Kategoria_ID = k.ID_Kategoria
WHERE t.Kategoria_ID IN (2, 3, 4);

-- 4. Dane wszystkich pracownik�w, kt�rzy nie brali udzia�u w �adnej sprzeda�y
SELECT *
FROM tblPracownicy p
LEFT JOIN tblSprzedaz s ON s.Pracownik_ID = p.IDPracownika
WHERE s.ID_Sprzedaz IS NULL

